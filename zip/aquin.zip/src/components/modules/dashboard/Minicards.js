import React from "react";
import { Card, CardBody, Row, Col } from "reactstrap";
import ViewInArIcon from "@mui/icons-material/ViewInAr";
import LayersIcon from "@mui/icons-material/Layers";
import SellIcon from "@mui/icons-material/Sell";
import WorkHistoryIcon from "@mui/icons-material/WorkHistory";

function Minicards() {
  return (
    <React.Fragment>
      <Row className="mainn">
        <Col xl={3} sm={6}>
          <Card className="mini-stat bg-primary" id="cards">
            <CardBody className="card-body mini-stat-img">
              <div className="mini-stat-icon">
                <i className={"float-end mdi mdi-" + ViewInArIcon}>
                  {" "}
                  <ViewInArIcon fontSize="large" />
                </i>
              </div>
              <div className="text-white">
                <h6 className="text-uppercase mb-3 font-size-16 text-white">
                  TOTAL MEMBERS
                </h6>
                <h2 className="mb-4 text-white">200</h2>
                <span
                  style={{
                    background: "rgb(236,83,108)",
                    color: "white",
                    fontSize: "12px",
                    padding: "1px",
                  }}
                >
                  {" "}
                  21{" "}
                </span>
                <span className="ms-2">From previous period</span>
              </div>
            </CardBody>
          </Card>
        </Col>

        <Col xl={3} sm={6}>
          <Card className="mini-stat bg-primary" id="cards">
            <CardBody className="card-body mini-stat-img">
              <div className="mini-stat-icon">
                <i className={"float-end mdi mdi"}>
                  <LayersIcon fontSize="large" />{" "}
                </i>
              </div>
              <div className="text-white">
                <h6 className="text-uppercase mb-3 font-size-16 text-white">
                  TOTAL TopUps
                </h6>
                <h2 className="mb-4 text-white">₹200</h2>
                <span
                  style={{
                    background: "rgb(41,187,227)",
                    color: "white",
                    fontSize: "12px",
                    padding: "1px",
                  }}
                >
                  {" "}
                  21{" "}
                </span>{" "}
                <span className="ms-2">From previous period</span>
              </div>
            </CardBody>
          </Card>
        </Col>
        <Col xl={3} sm={6}>
          <Card className="mini-stat bg-primary" id="cards">
            <CardBody className="card-body mini-stat-img">
              <div className="mini-stat-icon">
                <i className={"float-end mdi mdi"}>
                  <SellIcon fontSize="large" />{" "}
                </i>
              </div>
              <div className="text-white">
                <h6 className="text-uppercase mb-3 font-size-16 text-white">
                  TOTAL MEMBERS
                </h6>
                <h2 className="mb-4 text-white">₹200</h2>
                <span
                  style={{
                    background: "rgb(236,83,108)",
                    color: "white",
                    fontSize: "12px",
                    padding: "1px",
                  }}
                >
                  {" "}
                  21{" "}
                </span>{" "}
                <span className="ms-2">From previous period</span>
              </div>
            </CardBody>
          </Card>
        </Col>
        <Col xl={3} sm={6} >
          <Card className="mini-stat bg-primary" id="cards">
            <CardBody className="card-body mini-stat-img">
              <div className="mini-stat-icon">
                <i className={"float-end mdi mdi-"}>
                  <WorkHistoryIcon
                    fontSize="large"
                    style={{ MarginBottom: "5px" }}
                  />{" "}
                </i>
              </div>
              <div className="text-white">
                <h6 className="text-uppercase mb-3 font-size-16 text-white">
                  TOTAL MEMBERS
                </h6>
                <h2 className="mb-4 text-white">₹200</h2>
                <span
                  style={{
                    background: "rgb(245,178,37)",
                    color: "white",
                    fontSize: "12px",
                    padding: "1px",
                  }}
                >
                  {" "}
                  21{" "}
                </span>{" "}
                <span className="ms-2">From previous period</span>
              </div>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </React.Fragment>
  );
}

export default Minicards;
