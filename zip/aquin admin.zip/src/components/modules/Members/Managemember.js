import React, { useState } from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  Table,
} from "reactstrap";
import Form from "react-bootstrap/Form";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import BlockIcon from "@mui/icons-material/Block";
import VisibilityIcon from "@mui/icons-material/Visibility";
import user2 from "../../assets/images/users/user-2.jpg";
import user3 from "../../assets/images/users/user-3.jpg";
import user4 from "../../assets/images/users/user-4.jpg";
import user5 from "../../assets/images/users/user-5.jpg";
import user6 from "../../assets/images/users/user-6.jpg";
import user7 from "../../assets/images/users/user-7.jpg";
import { Link, NavLink } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Typography from "@mui/material/Typography";

import Modal from "react-bootstrap/Modal";
import Stack from "@mui/material/Stack";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";

import ReactPaginate from "react-paginate";

import ReactHTMLTableToExcel from "react-html-table-to-excel";
import html2canvas from "html2canvas";
import pdfMake from "pdfmake";
import Sidebarres from "../../sidebar/Sidebarres";

function Managemember() {
  const [show, setShow] = useState(true);

  const users = [
    {
      id: 1,
      imgUrl: user2,
      designation: "Right",
      name: "Katherine J. McAvoy",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",
      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
    {
      id: 2,
      imgUrl: user3,
      designation: "Creative Director",
      name: "Richard L. Jackson",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",
      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
    {
      id: 3,
      imgUrl: user4,
      designation: "Creative Director",
      name: "Joshua D. Pearson",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",
      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
    {
      id: 4,
      imgUrl: user5,
      designation: "Creative Director",
      name: "Michael J. Folma",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",

      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
    {
      id: 5,
      imgUrl: user6,
      designation: "Creative Director",
      name: "Samuel P. Augustus",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",
      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
    {
      id: 6,
      imgUrl: user7,
      designation: "Creative Director",
      name: "Joseph D. Starnes",
      phone: "999 999 9999",
      password: "123",
      doj: "12/12/2022",
      topup: "16/10/2021- 5000",
      Sponsor: "Katherine",
      Sponsorc: "100001",
      socials: [
        {
          id: 1,
          title: "View",
          icon: "fas fa-eye",
          link: "#",
          colorclass: "success",
        },
        {
          id: 2,
          title: "Edit",
          icon: "fas fa-user-edit",
          link: "#",
          colorclass: "primary",
        },
        {
          id: 3,
          title: "Delete",
          icon: "fas fa-trash",
          link: "#",
          colorclass: "danger",
        },
        {
          id: 4,
          title: "Block",
          icon: "fas fa-ban",
          link: "#",
          colorclass: "dark",
        },
      ],
    },
  ];
  const [user, setuser] = useState([]);

  const genPdf = () => {
    html2canvas(document.getElementById("empTable")).then((canvas) => {
      var data = canvas.toDataURL();
      var pdfExportSetting = {
        content: [
          {
            image: data,
            width: 500,
          },
        ],
      };
      pdfMake.createPdf(pdfExportSetting).download("file.pdf");
    });
  };

  const [search, setsearch] = useState("");
  const [listPerPage] = useState(10);
  const [pageNumber, setPageNumber] = useState(0);

  const pagesVisited = pageNumber * listPerPage;
  const lists = user.slice(pagesVisited, pagesVisited + listPerPage);
  const pageCount = Math.ceil(user.length / listPerPage);

  const changePage = ({ selected }) => {
    setPageNumber(selected);
  };

  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
      <div className='backgrounimgstyle'>
        <Sidebar />
        </div>
         <div className='drawecontent'>
        <Sidebarres />
        </div>
        <CssBaseline />
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link
              underline="hover"
              color="inherit"
              href="/"
              style={{ color: "black" }}
            >
              Dashboard
            </Link>

            <Typography color="text.primary">Members List</Typography>
          </Breadcrumbs>
          <Row className="mb-3" style={{ paddingTop: "20px" }}>
            <Col></Col>
            <Col>
              <div style={{ float: "right" }}>
                <Button
                  onClick={() => setShow(true)}
                  type="button"
                  color="link"
                  className="waves-effect"
                  style={{
                    backgroundColor: show ? "rgb(16,101,156)" : "",
                    color: show ? "white" : "black",
                    textDecoration: "none",
                  }}
                >
                  <i class="fa fa-th-large" aria-hidden="true"></i> Grid view
                </Button>

                <Button
                  type="button"
                  color="link"
                  className="waves-effect"
                  onClick={() => setShow(false)}
                  style={{
                    backgroundColor: !show ? "rgb(16,101,156)" : "",
                    color: !show ? "white" : "black",
                    paddingRight: "10px",
                    textDecoration: "none",
                  }}
                >
                  <i class="fa fa-bars" aria-hidden="true"></i> List view
                </Button>
              </div>
            </Col>
          </Row>
          {show ? (
            <>
              <Row>
                {users.map((user, key) => (
                  <Col xl="4" md="6" key={key} className="pt-4">
                    <Card className="directory-card" id="cards">
                      <div>
                        <div className="directory-bg text-center">
                          <div className="directory-overlay">
                            <img
                              className="rounded-circle avatar-lg img-thumbnail"
                              src={user.imgUrl}
                              alt="Generic placeholder"
                              style={{ height: "100px" }}
                            />
                          </div>
                        </div>

                        <div className="directory-content text-center p-4">
                          <p className=" mt-4">Member Id: {user.id}</p>
                          <h4 className="font-size-16"> {user.name}</h4>
                          <Row className="mt-4">
                            <Col md="6">
                              <h6 className="mt-1">Phone No:</h6>
                            </Col>
                            <Col md="6">
                              <p className="mt-1">{user.phone}</p>
                            </Col>
                            <Col md="6">
                              <h6 className="mt-1">Sponsor Name:</h6>
                            </Col>
                            <Col md="6">
                              <p className="mt-1 text-left">{user.Sponsor}</p>
                            </Col>
                            <Col md="6">
                              <h6 className="mt-1">Sponsor Code: </h6>
                            </Col>
                            <Col md="6">
                              <p className="mt-1 text-left">{user.Sponsorc}</p>
                            </Col>
                            <Col md="6">
                              <h6 className="mt-1">Date Of Joining: </h6>
                            </Col>
                            <Col md="6">
                              <p className="mt-1 text-left">{user.doj}</p>
                            </Col>
                          </Row>
                          <ul className="social-links list-inline mb-0 mt-4">
                            <div
                              style={{
                                width: "30px",
                                height: "30px",
                                lineHeight: "30px",
                                color: "white",
                                background: "#29bbe3",
                                borderRadius: "50%",
                                display: "inline-block",
                                marginRight: "20px",
                              }}
                            >
                              <VisibilityIcon fontSize="small" />
                            </div>
                            <div
                              style={{
                                width: "30px",
                                height: "30px",
                                lineHeight: "30px",
                                color: "white",
                                background: "#7a6fbe",
                                borderRadius: "50%",
                                display: "inline-block",
                                marginRight: "20px",
                              }}
                            >
                              <EditIcon fontSize="small" />
                            </div>
                            <div
                              style={{
                                width: "30px",
                                height: "30px",
                                lineHeight: "30px",
                                color: "white",
                                background: "#ec536c",
                                borderRadius: "50%",
                                display: "inline-block",
                                marginRight: "20px",
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </div>
                            <div
                              style={{
                                width: "30px",
                                height: "30px",
                                lineHeight: "30px",
                                color: "white",
                                background: "#2b3a4a",
                                borderRadius: "50%",
                                display: "inline-block",
                                marginRight: "20px",
                              }}
                            >
                              <BlockIcon fontSize="small" />
                            </div>
                          </ul>
                        </div>
                      </div>
                    </Card>
                  </Col>
                ))}
              </Row>
            </>
          ) : (
            <Row style={{ paddingTop: "30px" }}>
              <Col xs="12">
                <Card id="cards">
                  <CardBody>
                    <Row>
                      <Col>
                        <ReactHTMLTableToExcel
                          className="btn btn-primary m-2"
                          table="empTable"
                          filename="ReportExcel"
                          sheet="Sheet"
                          buttonText="Excel"
                          style={{ color: "white" }}
                        />
                        <Button
                          type="button"
                          className="btn btn-danger "
                          onClick={genPdf}
                        >
                          Pdf
                        </Button>
                        {/* <div style={{ float: "right" }}>
                          <Button
                            className="btn btn-primary float-right"
                            style={{ color: "white" }}
                            onClick={handleShow}
                          >
                            + Add New
                          </Button>
                        </div> */}
                      </Col>
                    </Row>
                    <div className="col vbtn" style={{ float: "right" }}>
                      <Form.Group controlId="formBasicEmail">
                        <Form.Control
                          type="text"
                          placeholder="Search"
                          onChange={(e) => {
                            setsearch(e.target.value);
                          }}
                        />
                      </Form.Group>
                    </div>
                    <Row className="mt-5">
                      <Col>
                        <Table striped bordered hover id="empTable">
                          <thead>
                            <tr>
                              <th>S.No</th>
                              <th>Name</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>1</td>
                              <td>Mark</td>
                              <td>@fat</td>
                              <td>
                                <EditIcon
                                  style={{ fontSize: "30px", color: "black" }}
                                />
                                <DeleteForeverIcon
                                  style={{ fontSize: "30px", color: "red" }}
                                />
                              </td>
                            </tr>
                            <tr>
                              <td>2</td>
                              <td>Jacob</td>
                              <td>Thornton</td>
                              <td>
                                <EditIcon
                                  style={{ fontSize: "30px", color: "black" }}
                                />
                                <DeleteForeverIcon
                                  style={{ fontSize: "30px", color: "red" }}
                                />
                              </td>
                            </tr>
                            <tr>
                              <td>3</td>
                              <td>Larry the Bird</td>
                              <td>@twitter</td>
                              <td>
                                <EditIcon
                                  style={{ fontSize: "30px", color: "black" }}
                                />
                                <DeleteForeverIcon
                                  style={{ fontSize: "30px", color: "red" }}
                                />
                              </td>
                            </tr>
                          </tbody>
                        </Table>
                        <div className="mt-3" style={{ float: "right" }}>
                          <Stack spacing={2}>
                            <ReactPaginate
                              previousLabel={"Previous"}
                              nextLabel={"Next"}
                              pageCount={pageCount}
                              onPageChange={changePage}
                              containerClassName={"pagination"}
                              previousLinkClassName={"previousBttn"}
                              nextLinkClassName={"nextBttn"}
                              disabledClassName={"disabled"}
                              activeClassName={"active"}
                              total={lists.length}
                            />
                          </Stack>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          )}
        </Box>
      </Box>
    </div>
  );
}

export default Managemember;
