import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Link } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import EditIcon from "@mui/icons-material/Edit";
import { Row, Col, Card, CardBody, CardTitle, Table } from "reactstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Sidebarres from "../../sidebar/Sidebarres";

function Transations() {
  const [editResults, seteditResults] = React.useState(false);
  const editfield = () => seteditResults(false);

  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
      <div className='backgrounimgstyle'>
        <Sidebar />
        </div>
         <div className='drawecontent'>
        <Sidebarres />
        </div>
        <CssBaseline />
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link color="inherit" href="/" style={{ color: "black" }}>
              Dashboard
            </Link>
          </Breadcrumbs>

          <React.Fragment>
            <Row style={{ paddingTop: "30px" }}>
              <Col xs="12">
                {editResults ? (
                  <Card id="cards">
                    <CardBody>
                      <CardTitle className="h4">Coins Edit </CardTitle>

                      <Form>
                        <Row>
                          <Col md="3">
                            <Form.Group
                              className="mb-3"
                              controlId="formBasicEmail"
                            >
                              <Form.Label> Min Value</Form.Label>
                              <Form.Control
                                type="email"
                                placeholder="Min Value"
                              />
                            </Form.Group>
                          </Col>
                          <Col md="3">
                            <Form.Group
                              className="mb-3"
                              controlId="formBasicEmail"
                            >
                              <Form.Label> Max Value</Form.Label>
                              <Form.Control
                                type="email"
                                placeholder=" Max Value"
                              />
                            </Form.Group>
                          </Col>
                          <Col md="3">
                            <div style={{ paddingTop: "30px" }}>
                              <Button variant="primary" type="submit">
                                Submit
                              </Button>
                            </div>
                          </Col>
                        </Row>
                      </Form>
                    </CardBody>
                  </Card>
                ) : (
                  ""
                )}

                <Card id="cards">
                  <CardBody>
                    <CardTitle className="h4">Coin Details </CardTitle>
                    <div style={{ float: "right", paddingLeft: "20px" }}>
                      <Button
                        className="btn btn-primary"
                        onClick={() => {
                          seteditResults(!editResults);
                        }}
                      >
                        <EditIcon style={{ color: "white" }} />
                      </Button>
                    </div>
                    <Row>
                      <Col>
                        <div className="table-responsive">
                          <Table className="table table-bordered ">
                            <tbody>
                              <tr>
                                <th> Min Value :</th>
                                <td>300</td>
                              </tr>
                              <tr>
                                <th> Max Value :</th>
                                <td>300</td>
                              </tr>
                            </tbody>
                          </Table>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </React.Fragment>
        </Box>
      </Box>
    </div>
  );
}

export default Transations;

{
  /* <div className="table-responsive">
{user.length >= 1 ? (
  <Table
    bordered
    className="mt-4"
    id="empTable"
    aria-describedby="xin_table_info"
    style={{ overflowX: "hidden" }}
  >
    <thead style={{ background: "#5db3de" }}>
      <tr style={{ color: "#fff" }}>
        <th>Sl.No</th>
        <th>State Name</th>
        <th>Country</th>
        <th>Description</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      {lists
        .filter((value) => {
          if (search === !null) {
            return value;
          } else if (
            value.title
              .toLowerCase()
              .includes(search.toLowerCase())
          ) {
            return value;
          }
        })
        .map((data, i) => {
          return (
            <tr key={i}>
              <td>{(pageNumber - 1) * 10 + i + 11}</td>
              <td>{data.title}</td>
              <td>{data.countryName}</td>
              <td>{data.description}</td>
              <td>
                {data.status === true || data.status == "true"
                  ? "active"
                  : "Inactive"}
              </td>
              <td>
                {" "}
                <EditIcon
                  onClick={() => {
                    getpopup(data);
                  }}
                  style={{ fontSize: "30px", color: "black" }}
                />{" "}
                <DeleteForeverIcon
                  onClick={() => {
                    manageDelete(data);
                  }}
                  style={{ fontSize: "30px", color: "red" }}
                />
              </td>
            </tr>
          );
        })}
    </tbody>
  </Table>
) : (
  <center>
    <h5 style={{ textAlign: "center" }}>
      {" "}
      <CircularProgress />
    </h5>
  </center>
)}
<div className="mt-3" style={{ float: "right" }}>
  <Stack spacing={2}>
    <ReactPaginate
      previousLabel={"Previous"}
      nextLabel={"Next"}
      pageCount={pageCount}
      onPageChange={changePage}
      containerClassName={"pagination"}
      previousLinkClassName={"previousBttn"}
      nextLinkClassName={"nextBttn"}
      disabledClassName={"disabled"}
      activeClassName={"active"}
      total={lists.length}
    />
  </Stack>
</div>
<ToastContainer />
</div> */
}
