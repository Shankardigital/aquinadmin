import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Link } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import EditIcon from "@mui/icons-material/Edit";
import { Row, Col, Card, CardBody, CardTitle, Table } from "reactstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Sidebarres from "../../sidebar/Sidebarres";

function Coins() {
  const [editResults, seteditResults] = React.useState(false);
  const editfield = () => seteditResults(false);

  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
      <div className='backgrounimgstyle'>
        <Sidebar />
        </div>
         <div className='drawecontent'>
        <Sidebarres />
        </div>
        <CssBaseline />
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link color="inherit" href="/" style={{ color: "black" }}>
              Dashboard
            </Link>
          </Breadcrumbs>

          <React.Fragment>
            <Row style={{ paddingTop: "30px" }}>
              <Col xs="12">
                {editResults ? (
                  <Card id="cards">
                    <CardBody>
                      <CardTitle className="h4">Coins Edit </CardTitle>

                      <Form>
                        <Row>
                          <Col md="3">
                            <Form.Group
                              className="mb-3"
                              controlId="formBasicEmail"
                            >
                              <Form.Label>Coin Value</Form.Label>
                              <Form.Control
                                type="email"
                                placeholder="Coin Value"
                              />
                            </Form.Group>
                          </Col>
                          <Col md="3">
                            <div style={{ paddingTop: "30px" }}>
                              <Button variant="primary" type="submit">
                                Submit
                              </Button>
                            </div>
                          </Col>
                        </Row>
                      </Form>
                    </CardBody>
                  </Card>
                ) : (
                  ""
                )}

                <Card id="cards">
                  <CardBody>
                    <CardTitle className="h4">Coin Details </CardTitle>
                    <div style={{ float: "right", paddingLeft: "20px" }}>
                      <Button
                        className="btn btn-primary"
                        onClick={() => {
                          seteditResults(!editResults);
                        }}
                      >
                        <EditIcon style={{ color: "white" }} />
                      </Button>
                    </div>
                    <Row>
                      <Col>
                        <div className="table-responsive">
                          <Table className="table table-bordered ">
                            <tbody>
                              <tr>
                                <th> current Value :</th>
                                <td>300</td>
                              </tr>
                            </tbody>
                          </Table>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </React.Fragment>
        </Box>
      </Box>
    </div>
  );
}

export default Coins;
