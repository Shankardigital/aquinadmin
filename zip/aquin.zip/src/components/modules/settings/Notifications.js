import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Link } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import EditIcon from "@mui/icons-material/Edit";
import { Row, Col, Card, CardBody, CardTitle, Table } from "reactstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import Stack from "@mui/material/Stack";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";

import ReactPaginate from "react-paginate";

import ReactHTMLTableToExcel from "react-html-table-to-excel";
import html2canvas from "html2canvas";
import pdfMake from "pdfmake";
import Sidebarres from "../../sidebar/Sidebarres";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import Typography from "@mui/material/Typography";

function Notifications() {
  const [editResults, seteditResults] = React.useState(false);
  const editfield = () => seteditResults(false);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [form, setform] = useState({});
  const [show1, setShow1] = useState(false);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);
  const [user1, setuser1] = useState([]);
  const [user, setuser] = useState([]);

  const [Files, setFiles] = useState("");

  const [Files1, setFiles1] = useState("");

  const changeHandler = (e) => {
    setFiles(e.target.files);
  };

  const changeHandler1 = (e) => {
    setFiles1(e.target.files);
  };

  const handleChange = (e) => {
    let myUser = { ...form };
    myUser[e.target.name] = e.target.value;
    setform(myUser);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addCategory();
  };

  useEffect(() => {
    getCategory();
  }, []);

  const api_url = "http://103.186.185.77:5013";

  const getCategory = () => {
    var token = sessionStorage.getItem("token");
    axios
      .post(
        "http://103.186.185.77:5013/api/v1/admin/notify/getallnotify",
        {},

        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then((res) => {
        setuser(res.data.notifyResult);
        console.log(res.data.notifyResult);
      });
  };

  const addCategory = () => {
    const dataArray = new FormData();
    dataArray.append("title", form.title);
    dataArray.append("description", form.description);
    for (let i = 0; i < Files.length; i++) {
      dataArray.append("notifyImg", Files[i]);
    }
    var token = sessionStorage.getItem("token");
    axios
      .post("http://103.186.185.77:5013/api/v1/admin/notify/addnotify", dataArray, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            handleClose();
            getCategory();
            clearForm();
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };

  const handleChange1 = (e) => {
    let myUser = { ...user1 };
    myUser[e.target.name] = e.target.value;
    setuser1(myUser);
  };

  const handleSubmit1 = (e) => {
    e.preventDefault();
    updateCategory();
  };

  const getpopup = (data) => {
    setuser1(data);
    handleShow1();
    handleSubmit1(data);
  };

  const updateCategory = () => {
    const data1 = user1._id;
    const dataArray = new FormData();
    dataArray.append("title", user1.title);
    dataArray.append("description", user1.description);
    dataArray.append("status", user1.status);
    var token = sessionStorage.getItem("token");

    axios
      .put(
        "http://103.186.185.77:5001/api/admin/country/editone" + "/" + dataArray,
        user1,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            handleClose1();
            getCategory();
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };

  const manageDelete = (data) => {
    const confirmBox = window.confirm("Do you really want to Delete?");
    if (confirmBox === true) {
      deleteUser(data);
    }
  };

  const deleteUser = (data) => {
    var token = sessionStorage.getItem("token");
    const data1 = data._id;
    console.log(data1);
    axios
      .delete(
        "http://103.186.185.77:5001/api/admin/country/removeone" + "/" + data1,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            getCategory();
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };
  const [search, setsearch] = useState("");
  const [listPerPage] = useState(10);
  const [pageNumber, setPageNumber] = useState(0);

  const pagesVisited = pageNumber * listPerPage;
  const lists = user.slice(pagesVisited, pagesVisited + listPerPage);
  const pageCount = Math.ceil(user.length / listPerPage);

  const changePage = ({ selected }) => {
    setPageNumber(selected);
  };

  const clearForm = () => {
    setform({
      title: "",
      description: "",
    });
  };

  const genPdf = () => {
    html2canvas(document.getElementById("empTable")).then((canvas) => {
      var data = canvas.toDataURL();
      var pdfExportSetting = {
        content: [
          {
            image: data,
            width: 500,
          },
        ],
      };
      pdfMake.createPdf(pdfExportSetting).download("file.pdf");
    });
  };

  const breadcrumbs = [
    <Link underline="hover" key="1" color="inherit">
      Dashboard
    </Link>,

    <Typography key="3" color="text.primary">
      BankList
    </Typography>,
  ];

  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
        <div className="backgrounimgstyle">
          <Sidebar />
        </div>
        <div className="drawecontent">
          <Sidebarres />
        </div>
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link color="inherit" href="/" style={{ color: "black" }}>
              Dashboard
            </Link>
          </Breadcrumbs>

          <React.Fragment>
            <Row style={{ paddingTop: "30px" }}>
              <Col xs="12">
                <Card id="cards">
                  <CardBody>
                    <Row>
                      <Col>
                        <ReactHTMLTableToExcel
                          className="btn btn-primary m-2"
                          table="empTable"
                          filename="ReportExcel"
                          sheet="Sheet"
                          buttonText="Excel"
                          style={{ color: "white" }}
                        />
                        <Button
                          type="button"
                          className="btn btn-danger "
                          onClick={genPdf}
                        >
                          Pdf
                        </Button>
                        <div style={{ float: "right" }}>
                          <Button
                            className="btn btn-primary float-right"
                            style={{ color: "white" }}
                            onClick={handleShow}
                          >
                            + Add New
                          </Button>
                        </div>
                      </Col>
                    </Row>
                    <div className="col vbtn" style={{ float: "right" }}>
                      <Form.Group controlId="formBasicEmail">
                        <Form.Control
                          type="text"
                          placeholder="Search"
                          onChange={(e) => {
                            setsearch(e.target.value);
                          }}
                        />
                      </Form.Group>
                    </div>
                    <Row className="mt-5">
                      <Col>
                        <Table striped bordered hover id="empTable">
                          <thead>
                            <tr>
                              <th>S.No</th>
                              <th>title</th>
                              <th>image</th>
                              <th>description</th>
                              <th>status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {lists
                              .filter((value) => {
                                if (search === !null) {
                                  return value;
                                } else if (
                                  value.title
                                    .toLowerCase()
                                    .includes(search.toLowerCase())
                                ) {
                                  return value;
                                }
                              })
                              .map((data, i) => {
                                return (
                                  <tr key={i}>
                                    <td>{(pageNumber - 1) * 10 + i + 11}</td>
                                    <td>{data.title}</td>
                                    <td>
                                      {" "}
                                      <img
                                        src={api_url + "/" + data.image}
                                        style={{
                                          width: "100px",
                                          cursor: "pointer",
                                        }}
                                      ></img>
                                    </td>
                                    <td>{data.description}</td>
                                    <td>
                                      {data.status === true ||
                                      data.status == "true"
                                        ? "active"
                                        : "Inactive"}
                                    </td>
                                    <td>
                                      {" "}
                                      <EditIcon
                                        onClick={() => {
                                          getpopup(data);
                                        }}
                                        style={{
                                          fontSize: "30px",
                                          color: "black",
                                        }}
                                      />{" "}
                                      <DeleteForeverIcon
                                        onClick={() => {
                                          manageDelete(data);
                                        }}
                                        style={{
                                          fontSize: "30px",
                                          color: "red",
                                        }}
                                      />
                                    </td>
                                  </tr>
                                );
                              })}
                          </tbody>
                        </Table>
                        <div className="mt-3" style={{ float: "right" }}>
                          <Stack spacing={2}>
                            <ReactPaginate
                              previousLabel={"Previous"}
                              nextLabel={"Next"}
                              pageCount={pageCount}
                              onPageChange={changePage}
                              containerClassName={"pagination"}
                              previousLinkClassName={"previousBttn"}
                              nextLinkClassName={"nextBttn"}
                              disabledClassName={"disabled"}
                              activeClassName={"active"}
                              total={lists.length}
                            />
                          </Stack>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
            </Row>

            <Modal
              show={show}
              onHide={handleClose}
              style={{ marginTop: "80px" }}
            >
              <Modal.Header>
                <Modal.Title>
                  <h3>Add Notification</h3>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <div className="mt-5 mt-lg-4">
                  <form
                    method="post"
                    onSubmit={(e) => {
                      handleSubmit(e);
                    }}
                  >
                    <label> Notification Name: </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter 
                      Notification Name:"
                      required
                      name="title"
                      value={form.title}
                      onChange={(e) => {
                        handleChange(e);
                      }}
                    />

                    <label className="mt-3">Image :</label>
                    <input
                      type="file"
                      className="form-control"
                      name="image"
                      multiple
                      onChange={changeHandler}
                      required
                    />

                    <label className="mt-3">Description :</label>
                    <textarea
                      class="form-control "
                      id="exampleFormControlTextarea3"
                      rows="3"
                      name="description"
                      required
                      value={form.description}
                      onChange={(e) => {
                        handleChange(e);
                      }}
                    ></textarea>
                    <div className="row mt-3">
                      <div className="col-sm-12">
                        <div>
                          <button
                            type="submit"
                            class="btn btn-sm btn-success save"
                            style={{
                              color: "white",
                              background: "rgb(13,85,143)",
                            }}
                          >
                            <i class="fa fa-check-circle"></i> Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </Modal.Body>
            </Modal>
            <Modal
              show={show1}
              onHide={handleClose1}
              style={{ marginTop: "80px" }}
            >
              <Modal.Header>
                <Modal.Title>
                  <h3>Edit State</h3>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <form
                  method="post"
                  onSubmit={(e) => {
                    handleSubmit1(e);
                  }}
                >
                  <div class="container">
                    <label> State Name</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter State Name"
                      required
                      name="title"
                      value={user1.title}
                      onChange={(e) => {
                        handleChange1(e);
                      }}
                    />

                    <label className="mt-3">Image :</label>
                    <input
                      type="file"
                      className="form-control"
                      name="image"
                      multiple
                      onChange={changeHandler1}
                    />

                    <label className="mt-3">Description :</label>
                    <textarea
                      class="form-control "
                      id="exampleFormControlTextarea3"
                      rows="3"
                      name="description"
                      required
                      value={user1.description}
                      onChange={(e) => {
                        handleChange(e);
                      }}
                    ></textarea>
                    <div className="pt-3" style={{ float: "right" }}>
                      <button
                        type="button"
                        class="btn btn-sm btn-danger m-2"
                        onClick={handleClose1}
                      >
                        <i class="fa fa-times-circle"></i>
                        <span aria-hidden="true"> Cancel</span>
                      </button>
                      <button
                        type="submit"
                        class="btn btn-sm btn-primiry "
                        style={{
                          color: "white",
                          background: "rgb(13,85,143)",
                        }}
                      >
                        <i class="fa fa-check-circle"></i> Submit
                      </button>
                    </div>
                  </div>
                </form>
              </Modal.Body>
            </Modal>
          </React.Fragment>
        </Box>
      </Box>
    </div>
  );
}

export default Notifications;
