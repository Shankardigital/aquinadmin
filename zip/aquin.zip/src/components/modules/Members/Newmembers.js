import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Row, Col, Card, CardBody, Button, Label } from "reactstrap";
import { ToastContainer, toast } from "react-toastify";
import { Link, NavLink } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Typography from "@mui/material/Typography";
import Sidebarres from "../../sidebar/Sidebarres";
import axios from "axios";

function Newmembers() {
  const [form, setform] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    addCategory();
  };
  const addCategory = () => {
    const dataArray = new FormData();
    dataArray.append("title", form.title);
    dataArray.append("status", form.status);
    var token = sessionStorage.getItem("token");
    axios
      .post(
        "http://103.186.185.77:5013/api/v1/admin/bankname/addbankname",
        form,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            console.log(res.data.message);
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };
  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
        <div className="backgrounimgstyle">
          <Sidebar />
        </div>
        <div className="drawecontent">
          <Sidebarres />
        </div>
        <CssBaseline />
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link
              underline="hover"
              color="inherit"
              href="/"
              style={{ color: "black" }}
            >
              Dashboard
            </Link>

            <Typography color="text.primary">Add New Member</Typography>
          </Breadcrumbs>
          <Row style={{ paddingTop: "30px" }}>
            <Col xl="12">
              <Card id="cards">
                <CardBody>
                  <form
                    method="post"
                    onSubmit={(e) => {
                      handleSubmit(e);
                    }}
                  >
                    <Row>
                      <Col md="3">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom01">
                            Name<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="Name"
                            placeholder="Name"
                            type="text"
                            errorMessage="Name"
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom07"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom01">
                            Mobile No<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="mobile"
                            placeholder="Mobile"
                            type="number"
                            errorMessage="Mobile No"
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom07"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom02">
                            Email<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="lastname"
                            placeholder="Email"
                            type="text"
                            errorMessage="Email"
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom02"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom02">
                            Date Of Birth<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="date"
                            placeholder="Date Of Birth"
                            type="date"
                            errorMessage="DOB"
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom02"
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom04">
                            Area<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="area"
                            placeholder="Area"
                            type="text"
                            errorMessage="Please provide a valid area."
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom04"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom03">
                            State<span className="text-danger">*</span>
                          </Label>

                          <select
                            errorMessage=" Please provide a valid tate."
                            validate={{ required: { value: true } }}
                            id="validationCustom03"
                            className="form-control"
                          >
                            {" "}
                            <option>Select</option>
                            <option>Andhra Pradesh</option>
                            <option>Arunachal Pradesh</option>
                            <option>Assam</option>
                            <option>Goa</option>
                          </select>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom05">
                            District<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="district"
                            placeholder="District"
                            type="text"
                            errorMessage=" Please provide a valid District."
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom05"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom05">
                            City<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="city"
                            placeholder="City"
                            type="text"
                            errorMessage=" Please provide a valid City."
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom05"
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom04">
                            Pin Code<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="Pin"
                            placeholder="Pin"
                            type="number"
                            errorMessage="Please provide a valid Pin."
                            className="form-control"
                            validate={{ required: { value: true } }}
                            id="validationCustom04"
                          />
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom05">
                            Gender<span className="text-danger">*</span>
                          </Label>

                          <select className="form-control">
                            <option>Select</option>
                            <option>Male</option>
                            <option>Female</option>
                          </select>
                        </div>
                      </Col>
                      <Col md="6">
                        <div className="mb-3">
                          <Label htmlFor="validationCustom09">
                            Address<span className="text-danger">*</span>
                          </Label>
                          <textarea
                            placeholder="Enter Address"
                            className="form-control"
                            errorMessage=" Please Enter Address."
                            validate={{ required: { value: true } }}
                            id="validationCustom09"
                          />
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xl="12">
                        {/* <h4 className="card-title">Sponsor Details:</h4> */}
                        <Row>
                          <Col md="6">
                            <div className="mb-4">
                              <Label htmlFor="validationCustom01">
                                Sponsor Id<span className="text-danger">*</span>
                              </Label>
                              <input
                                name="name"
                                placeholder="Sponsor Id"
                                type="text"
                                errorMessage=" Sponsor Id"
                                className="form-control"
                                validate={{ required: { value: true } }}
                                id="validationCustom01"
                              />
                            </div>
                          </Col>
                          <Col md="6">
                            <div className="mb-4">
                              <Label htmlFor="validationCustom02">
                                Sponsor Name
                                <span className="text-danger">*</span>
                              </Label>
                              <input
                                name="Sponsor Name"
                                placeholder="Sponsor Name"
                                type="text"
                                errorMessage="Sponsor Name"
                                className="form-control"
                                validate={{ required: { value: true } }}
                                id="validationCustom02"
                              />
                            </div>
                          </Col>
                        </Row>
                      </Col>
                    </Row>

                    <div style={{ float: "right" }}>
                      <Row>
                        <Col>
                          <Button
                            color="danger"
                            className="membtnstyle"
                            type="submit"
                          >
                            Cancel
                          </Button>
                        </Col>
                        <Col>
                          <Button
                            color="primary"
                            className="membtnstyle"
                            type="submit"
                          >
                            Submit
                          </Button>
                        </Col>
                      </Row>
                    </div>
                  </form>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Box>
      </Box>
    </div>
  );
}

export default Newmembers;
