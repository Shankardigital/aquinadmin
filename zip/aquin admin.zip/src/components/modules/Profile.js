import React from "react";
import Box from "@mui/material/Box";
import Sidebar from "../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Link } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import avatar from "../assets/images/users/user-6.jpg";
import { Row, Col, Card, Alert, CardBody, Media, Button } from "reactstrap";
import Sidebarres from "../sidebar/Sidebarres";

function Profile() {
  return (
    <Box sx={{ display: "flex" }} className="mainn">
     <div className='backgrounimgstyle'>
        <Sidebar />
        </div>
         <div className='drawecontent'>
        <Sidebarres />
        </div>
      <CssBaseline />
      <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
        <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
          <Link color="inherit" href="/" style={{ color: "black" }}>
            Profile
          </Link>
        </Breadcrumbs>

        <Row className="mt-3">
          <Col xl="12" md="6">
            <Card className="directory-card" id="cards">
              <div>
                <div className="directory-bg text-center">
                  <div className="directory-overlay">
                    <img
                      className="rounded-circle avatar-lg img-thumbnail"
                      src={avatar}
                      alt="Generic placeholder"
                    />
                  </div>
                </div>

                <div className="directory-content text-center p-4">
                  <h4 className="font-size-16 mt-4">Sai</h4>
                </div>
              </div>
            </Card>
          </Col>
        </Row>
        <Card id="cards">
          <CardBody>
            <Row>
              <Col lg={6} className="ms-lg-auto">
                <div className="mt-5 mt-lg-4">
                  <h5 className="font-size-14 mb-4">
                    <i className="mdi mdi-arrow-right text-primary me-1"></i>{" "}
                    Edit Profile
                  </h5>
                  <form>
                    <div className="row mb-4">
                      <label
                        htmlFor="horizontal-firstname-input"
                        className="col-sm-4 col-form-label"
                      >
                        Name:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="text"
                          className="form-control"
                          id="horizontal-firstname-input"
                          placeholder="Enter Name"
                        />
                      </div>
                    </div>

                    <div className="row mb-4">
                      <label
                        htmlFor="horizontal-email-input"
                        className="col-sm-4 col-form-label"
                      >
                        Email:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="email"
                          className="form-control"
                          id="horizontal-email-input"
                          placeholder="Enter Email"
                        />
                      </div>
                    </div>

                    <div className="row mb-4">
                      <label
                        htmlFor="horizontal-email-input"
                        className="col-sm-4 col-form-label"
                      >
                        Image:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="File"
                          className="form-control"
                          id="horizontal-email-input"
                        />
                      </div>
                    </div>

                    <div className="row justify-content-end">
                      <div className="col-sm-12">
                        <div>
                          <button
                            type="submit"
                            className="btn btn-primary w-md"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </Col>

              <Col lg={6} className="ms-lg-auto">
                <div className="mt-5 mt-lg-4">
                  <h5 className="font-size-14 mb-4">
                    <i className="mdi mdi-arrow-right text-primary me-1"></i>
                    Change password
                  </h5>

                  <form>
                    <div className="row mb-4">
                      <label
                        htmlFor="horizontal-firstname-input"
                        className="col-sm-4 col-form-label"
                      >
                        Current password:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="text"
                          className="form-control"
                          id="horizontal-firstname-input"
                          placeholder="Enter  Current password"
                        />
                      </div>
                    </div>

                    <div className="row mb-4">
                      <label
                        htmlFor="horizontal-email-input"
                        className="col-sm-4 col-form-label"
                      >
                        Change password:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="email"
                          className="form-control"
                          id="horizontal-email-input"
                          placeholder="Enter Change password"
                        />
                      </div>
                    </div>

                    <div className="row  mb-4">
                      <label
                        htmlFor="horizontal-email-input"
                        className="col-sm-4 col-form-label"
                      >
                        Confirm password:
                      </label>
                      <div className="col-sm-8">
                        <input
                          type="text"
                          className="form-control"
                          id="horizontal-email-input"
                          placeholder="Enter Confirm password"
                        />
                      </div>
                    </div>

                    <div className="row justify-content-end">
                      <div className="col-sm-12">
                        <div>
                          <button
                            type="submit"
                            className="btn btn-primary w-md"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Box>
    </Box>
  );
}

export default Profile;
