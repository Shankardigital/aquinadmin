import React from "react";
import C3Chart from "react-c3js";
import "c3/c3.css";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
} from "reactstrap";

function Charts() {
  const data = {
    columns: [
      ["data1", 30, 200, 100, 400, 150, 250],
      ["data2", 50, 20, 10, 40, 15, 25],
    ],
  };
  const datas = {
    columns: [
      ["Download Sales", 12],
      ["In-Store Sales", 30],
      ["Mail-Order Sales", 20],
    ],
    type: "donut",
  };

  const donut = {
    title: "Total income 30",
    width: 30,
    label: { show: !1 },
  };

  const color = {
    pattern: ["#f0f1f4", "#7a6fbe", "#28bbe3"],
  };

  const size = {
    height: 300,
  };
  return (
    <div>
      <React.Fragment>
        <Card id="cards" className="mainn">
          <CardBody>
            <CardTitle className="h4 mb-4" style={{ color: "rgb(91,98,131)" }}>
              <h6>Daily Earnings</h6>
            </CardTitle>

            <Row className="text-center mt-4">
              <div className="col-6">
                <h5
                  className="font-size-20"
                  style={{ color: "rgb(91,98,131)" }}
                >
                  ₹56241
                </h5>
                <p className="text-muted" style={{ color: "rgb(91,98,131)" }}>
                  value
                </p>
              </div>
              <div className="col-6">
                <h5
                  className="font-size-20"
                  style={{ color: "rgb(91,98,131)" }}
                >
                  ₹23651
                </h5>
                <p className="text-muted" style={{ color: "rgb(91,98,131)" }}>
                  Total Income
                </p>
              </div>
            </Row>
            <div dir="ltr">
              <C3Chart
                data={datas}
                donut={donut}
                color={color}
                size={size}
                dir="ltr"
              />
            </div>
          </CardBody>
        </Card>
      </React.Fragment>
    </div>
  );
}

export default Charts;
