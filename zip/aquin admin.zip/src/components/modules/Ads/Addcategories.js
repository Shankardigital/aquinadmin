import React from "react";
import Box from "@mui/material/Box";
import Sidebar from "../../sidebar/Sidebar";
import CssBaseline from "@mui/material/CssBaseline";
import { Link } from "react-router-dom";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Sidebarres from "../../sidebar/Sidebarres";

function Addcategories() {
  return (
    <div>
      <Box sx={{ display: "flex" }} className="mainn">
      <div className='backgrounimgstyle'>
        <Sidebar />
        </div>
         <div className='drawecontent'>
        <Sidebarres />
        </div>
        <CssBaseline />
        <Box component="main" sx={{ flexGrow: 2, p: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" style={{ paddingTop: "70px" }}>
            <Link color="inherit" href="/" style={{ color: "black" }}>
              Dashboard
            </Link>
          </Breadcrumbs>
        </Box>
      </Box>
    </div>
  );
}

export default Addcategories;
